let tbl = document.getElementsByTagName("table");
let show = document.getElementById("show");
let button = document.querySelector("#btn");
let player = "X";

button.onclick = function () {
    let tr = ``;
    let arr = [];
    let num = 0;
    for (let i = 0; i < 9; i++) {
        arr[i] = i + 1;
    }
    for (let i = 0; i < 3; i++) {
        tr += `<tr>`;
        for (let j = 0; j < 3; j++) {
            tr += `<td id="click${arr[num]}" onclick="Click(${arr[num]})"> ${player[0]}</td>`;
            num++;
        };
        tr += `</tr>`;
    };
    show.innerHTML = tr;
};

function Click(x) {
    let td = document.getElementById("click");
    if (player === "X") {
        player = "O";
        return;
    } else if(player === "O") {
        player = "X";

    }
    console.log(Click);
}
